#include "Menu.h"

int8_t Menu_Start(int8_t Shift)
{
	if (Shift == 0)
	{
		if (Menu_Global.RunningMenu->isInit)
		{
			return 0;
		}
		else
		{
			Menu_RunMainMenu();
			return 1;
		}
	}
	else if (Shift == 1)
	{
		Menu_RunMainMenu();
	}
	else // if(Shift == -1)
	{
		Menu_Global.RunningMenu->isInit = 1;
		return 0;
	}
	return 0;
}


/*创建选项列表*/
struct Option_Class Menu_StartOptionList[] = {
		{"<<<"},
		{"tool", Menu_RunToolsMenu},
//		{"Games", Menu_RunGamesMenu},
		{"Setting", Menu_RunSettingMenu}, // 设置
		{"Info", Menu_Information},		  // 信息
		{".."}};

/*创建开始菜单对象*/
struct Menu_Class Menu_StartMenu = {.isInit = 1};

void Menu_RunMainMenu(void)
{
	if (Menu_StartMenu.isInit) // 由于开始菜单没有上级, 需手动配置部分参数;
	{
		Menu_MenuClassInit(&Menu_StartMenu, Menu_StartOptionList);
		/*手动配置区*******/
		Menu_StartMenu.Target_Window_X = 0;
		Menu_StartMenu.Window_X = 0;
		Menu_StartMenu.Window_Y = 64;
		Menu_Global.Cursor_Actual_X = 0;
		Menu_Global.Cursor_Actual_Y = 64;
	
		/*******手动配置区*/
	}

	Menu_RunWindow(&Menu_StartMenu);
}

void Menu_RunToolsMenu(void)
{
	/*创建选项列表*/
	static struct Option_Class Menu_ToolsOptionList[] = {
		{"<<<"},
//		{"定时器"/*, Menu_RunGamesMenu*/}, // 6-1 定时器定时中断
		{"环境温湿度",DHT11_Get},				   // 6-6 输入捕获模式测频率
		{"温度" ,Temp_Get},		   // 6-3 PWM驱动LED呼吸灯
		{"姿态获取",MPU6050_Get},				   // 6-7 PWMI模式测频率占空比
		{"心率血氧值",Max30102_Get},					   // 6-8 编码器接口测速
//		{"串口"},					   // 9-3 串口收发HEX数据包
		{"空气检测",MQ135_Get},					   // 空气质量
//		{"ADC"},					   // 8-2 DMA+AD多通道
		{".."}};
	
	/*创建菜单对象*/
	static struct Menu_Class Menu_ToolsMenu = {.isInit = 1};	//赋值初始化

	if (Menu_ToolsMenu.isInit)
	{
		Menu_MenuClassInit(&Menu_ToolsMenu, Menu_ToolsOptionList);
		/*手动配置区*******/
		
		/*******手动配置区*/
	}
	
	Menu_RunWindow(&Menu_ToolsMenu);
}



void Menu_Information(void)
{
	float Angle = 3640;
	while (1)
	{
		OLED_Clear();

		OLED_ShowImage(88, 8, 32, 32, goutou);
		OLED_Rotation_Block(88 + 16, 8 + 16, 16, Angle);

		Angle += Menu_RollEvent() * 8;

		if (Angle > 1)
		{
			Angle -= Angle / 32 + 1;
		}
		else if (Angle < -1)
		{
			Angle -= Angle / 32 - 1;
		}
		else
		{
			Angle = 0;
		}
		// Angle += 2;
		// Angle %= 360;

		OLED_ShowString(2, 0, "健康检测\nv1.2", OLED_8X16);
		OLED_ShowString(2, 32, "By:Adam", OLED_8X16);
		OLED_ShowString(2, 48, "UP:XiaoYang", OLED_8X16);

		OLED_Update();
		if (Menu_EnterEvent())
		{
			return;
		}
		if (Menu_BackEvent())
		{
			return;
		}
	}
}

/**********************************************************/
