#ifndef __TOOLS_H
#define __TOOLS_H

#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Menu.h"
#include "DHT11.h"
#include "algorithm.h"
#include "max30102.h"
#include "MPU6050.h"
#include "AD.h"
#include "onenet.h"
#include "esp8266.h"
#include "GY906.h"

#define MAX_BRIGHTNESS 255

//DHT11
extern uint8_t tmp1;
extern uint8_t hum1;
//MPU6050
extern int8_t ID;
extern int16_t AX, AY, AZ, GX, GY, GZ;
extern int16_t thre;
//MQ135
extern uint16_t ADvalue;
//GY906
extern uint8_t Temp1;

//DHT11
void DHT11_Get(void);
//MAX30102
void Max30102_Get(void);
void dis_DrawCurve(u32* data,u8 x);
//MPU6050
void MPU6050_Get(void);
//MQ135
void MQ135_Get(void);
//GY906
void Temp_Get(void);
#endif
