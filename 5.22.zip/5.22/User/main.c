#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"
#include "LED.h"
#include "DHT11.h"
#include "ESP8266.h"
#include "uart.h"
#include "Menu.h"
#include "Encoder.h"
#include "Timer.h"
#include "algorithm.h"
#include "max30102.h" 
#include "onenet.h"
#include <stdbool.h>
#include <math.h>
#include "Buzzer.h"


bool pose1 = true;
bool pose2 = true;

#define ESP8266_ONENET_INFO		"AT+CIPSTART=\"TCP\",\"mqtts.heclouds.com\",1883\r\n"
#define M_PI (3.14159265358979323846264338327950288)

u8 temp2,humi2;
u16 ADValue;
int16_t ax, ay, az, gx, gy, gz;
uint8_t Temp2;
// ����ȫ�ֱ������ڴ洢��̬�Ƕ�
float pitch = 0.0; // ������
float roll = 0.0;  // �����

void UpdateAttitude(int16_t AX, int16_t AY, int16_t AZ, int16_t GX, int16_t GY, int16_t GZ);
void fall(void);

void Hardware_Init(void)
{
	LED_Init();
	OLED_Init();
	MPU6050_Init();
	DHT11_Init();
	SMBus_Init();
	Timer_Init();
	Key_Init();
	Uart1_Init(115200);
	Uart2_Init(115200);	 	//���ڳ�ʼ��Ϊ115200
	max30102_init();
	AD_Init();	
	ESP8266_Init();
	Buzzer_Init();
}

int main(void)
{ 
	unsigned short timeCount = 0;	//���ͼ������
	
//	unsigned char *dataPtr = NULL;
	
	Hardware_Init();

	
	
	Uart_Printf(USART_DEBUG, "Connect MQTTs Server...\r\n");
	while(ESP8266_SendCmd(ESP8266_ONENET_INFO, "CONNECT"))
		Delay_ms(500);
	Uart_Printf(USART_DEBUG, "Connect MQTT Server Success\r\n");
//	
	while(OneNet_DevLink())			//����OneNET
		Delay_ms(500);
	
	OneNET_Subscribe();
	
	while(1)
	{
		OLED_Clear();
		Menu_ShowWallpaper(Win11Wallpaper);
		
		
//		dataPtr = ESP8266_GetIPD(0);

		
//		Delay_ms(10);
				
		if(Menu_Start(0) == 0)
		{
			if (Menu_EnterEvent())
			{
				Menu_Start(1);
			}
			else
			{
				if(++timeCount >= 100)									//���ͼ��5s
				{
					DHT11_Read_Data(&temp2,&humi2);
					ADValue =AD_GetValue();
					Temp2 = SMBus_ReadTemp();
					
					Uart_Printf(USART_DEBUG, "OneNet_SendData\r\n");
					OneNet_SendData();									//��������
					
					timeCount = 0;
					ESP8266_Clear();
				}
				fall();
			}
				
		}
		OLED_Update();
	}
}


void UpdateAttitude(int16_t AX, int16_t AY, int16_t AZ, int16_t GX, int16_t GY, int16_t GZ) 
	{
    // ���ٶȼƵĽǶȼ���
    float accPitch = atan2(AY, sqrt(AX * AX + AZ * AZ)) * (180.0 / M_PI);
    float accRoll = atan2(-AX, AZ) * (180.0 / M_PI);
 
    // �����ǻ��ֵõ����ٶ�
    float gyroPitch = pitch + (float)GY / 131.0; // 131 ���������������ȵ���
    float gyroRoll = roll + (float)GX / 131.0;
 
    // �ۺϼ��ٶȼƺ����������ݣ�ʹ�û����˲�
    float alpha = 0.98; // �����˲�ϵ����������Ҫ����
    pitch = alpha * gyroPitch + (1.0 - alpha) * accPitch;
    roll = alpha * gyroRoll + (1.0 - alpha) * accRoll;

}

void fall(void)
{
	MPU6050_GetData(&ax, &ay, &az, &gx, &gy, &gz);
	
	UpdateAttitude(ax, ay, az, gx, gy, gz);
	if (pitch > 30) {
 //           OLED_ShowString(4, 1, "Back   ");
			pose1 = false;
        } else if (pitch < -30) {
//            OLED_ShowString(4, 1, "Front  ");
			pose1 = false;
        } else {
//            OLED_ShowString(4, 1, "Normal ");
			pose1 = true;
        }
        
        if (roll < -70) {
//            OLED_ShowString(4, 10, "Right ");
			pose2 = false;
        } else if (roll > 0) {
//            OLED_ShowString(4, 10, "Left  ");
			pose2 = false;
        } else {
//            OLED_ShowString(4, 10, "Normal");
			pose2 = true;
        }
		
        if (!pose1 || !pose2) {
            // ������������
            Buzzer_OFF();
			LED1_OFF();
        } else {
            // �رշ�����
            Buzzer_ON();
			LED1_ON();
		}
}
